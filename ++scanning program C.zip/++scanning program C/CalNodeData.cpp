#include "CalNodeData.h"
#include "Node.h"

/*constructor*/
CalNodeData::CalNodeData(void){}

/*********************************************
*this function initialize vector of all the 
*son's node who need more robots
*********************************************/
void CalNodeData::initVectorSonsWhoNeedRobots(Node* node){
	//int numOfRobots;
	vector<Node*>::iterator it;
	vector<Node*> nodeSons=node->get_vector_sons();
	for (it = nodeSons.begin();it != nodeSons.end(); ++it){
		if((*it)->get_state()==not_visited && (*it)->getNextstate()==not_visited){
			if(checkIfSonNeedsMoreRobots(*it))
				vectorSonsWhoNeedRobots.push_back(*it);
				
	    }
	}
}
/*********************************************
*this function calculate how much not visited
*sons there is in the node's subtree,and 
*return  the result
*********************************************/
int CalNodeData::CalHowMuchNotVisitedSonsInMySubTree(Node* n){ 
	if(n->get_isLeaf() ){
		if( (n->get_state()==not_visited && n->getNextstate()==not_visited))
			return 1;
		else
			return 0;
	}
	
	else{
		 vector<Node*>::iterator it;
		 int count=0;
		  vector<Node*> sonsVector=n->get_vector_sons();

		for (it =sonsVector.begin();it != sonsVector.end(); ++it){
			
			count=count +  CalHowMuchNotVisitedSonsInMySubTree(*it);
		}
		if( (n->get_state()==not_visited && n->getNextstate()==not_visited))
			count++;

		return count;
	}
}
/*********************************************
*this function calculate how much robots will
*be in the node's "n" subtree in the next time
*********************************************/
int CalNodeData::CalHowMuchRobotsIWillHaveNextTimenMySubTree(Node* n){ /// current not visited son 
	int count=0;
	if(n->get_isLeaf()){
		
			return n->getNextRobotListSize();
	}
	else{
		 vector<Node*>::iterator it;
		  vector<Node*> sonsVector=n->get_vector_sons();
		for (it =sonsVector.begin();it != sonsVector.end(); ++it){ 
				count=count  +  CalHowMuchRobotsIWillHaveNextTimenMySubTree(*it);
		}
	} 
	if(n->getNextRobotListSize()>0)
		count= count + n->getNextRobotListSize();
	else if(n->getNextRobotListSize() == 0 && n->RobotsWhichIcanGive.size()>0 )
		count= count + n->RobotsWhichIcanGive.size();

	return count;

}

/*********************************************
*this function calculate how much robots the
*node "n" have now in his subtree,
*return the result
*********************************************/
int CalNodeData::CalHowMuchRobotsInMySubTree(Node* n){
	int count=0;
	if(n->get_isLeaf()){
		return (n->getCurrentRobotList().size() );
	}
	else{
		 vector<Node*>::iterator it;
		  vector<Node*> sonsVector=n->get_vector_sons();
		for (it =sonsVector.begin();it != sonsVector.end(); ++it){
			 count=count  +  CalHowMuchRobotsInMySubTree(*it);
		}
	} 
	return count + n->getCurrentRobotList().size();
}
/*********************************************
*this function chack if the the vector 
*vectorSonsWhoNeedRobots is empty or not,
*if its empty its means that there is no more
*sons who needs more robots
*if its empty return true, and false otherwise
*********************************************/
bool CalNodeData::CheckIfVectorIsEmpty(){
	if(vectorSonsWhoNeedRobots.size()==0)
		return true;
	else
		return false;
}
/*********************************************
*this function return the first son node in 
*the vector
*********************************************/
Node*  CalNodeData::getSonToGiveRobotForHim(){
	return vectorSonsWhoNeedRobots.front();
}
/*********************************************
*this function return sons who needs 
*more robots to his subtree for scanning it
*********************************************/
Node*  CalNodeData::get_son_to_give_robots(){
	vector<Node* >::iterator it;
	for (it = vectorSonsWhoNeedRobots.begin();it != vectorSonsWhoNeedRobots.end(); ++it){
		if( checkIfSonNeedsMoreRobots(*it)){
			return (*it);
		}
	}
	return NULL;
}

/*********************************************
*this function chack if the son in the input 
*needs more robots, if it is return true,
*false otherwise
*********************************************/
bool CalNodeData::checkIfSonNeedsMoreRobots(Node *son){
	
	int NumOfnotVisited=CalHowMuchNotVisitedSonsInMySubTree((son));
	int numOfRobotsInMySubTreeNext=CalHowMuchRobotsIWillHaveNextTimenMySubTree((son));
	int result=NumOfnotVisited - numOfRobotsInMySubTreeNext;
	if(result > 0) // the son need more robots 
		return true;

	else // the son doent need more robots
		return false;
	

}
/*destractor*/
CalNodeData::~CalNodeData(void){ }
