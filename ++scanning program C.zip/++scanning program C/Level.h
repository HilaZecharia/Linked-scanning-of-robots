
#ifndef LEVEL_H_
#define LEVEL_H_

class Level {
private:
	int numOfLevel;
	bool isItDespliteLevel;

public:
	Level();
	int getLevel();
	void setLevel(int l);
	void changeToDespliteLevel();
	bool isDespliteNode();
	virtual ~Level();
};

#endif /* LEVEL_H_ */
