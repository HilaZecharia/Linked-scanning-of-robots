#pragma once

#include <string>
#include <iostream>
#include <vector>
#include <algorithm> 

using namespace std;
class Node;
class CalNodeData
{
private:
	vector<Node*>  vectorSonsWhoNeedRobots;
	
public:
	CalNodeData(void);
	void initVectorSonsWhoNeedRobots(Node* node);
	int CalHowMuchRobotsInMySubTree(Node* n);
	int CalHowMuchNotVisitedSonsInMySubTree(Node* n);
	int CalHowMuchRobotsInMySubTree_NextTime(Node* n);
	Node*  getSonToGiveRobotForHim();
	bool CheckIfVectorIsEmpty();
	bool checkIfSonNeedsMoreRobots(Node *son);
	void addRobotToSon(Node* son);
	Node*  get_son_to_give_robots();
	int CalHowMuchNotVisitedSonsInMySubTreeWithOutRobots(Node* n);
	int CalHowMuchRobotsIWillHaveNextTimenMySubTree(Node* n);
	~CalNodeData(void);
};

