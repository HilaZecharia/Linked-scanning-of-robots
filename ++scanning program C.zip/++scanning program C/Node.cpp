#include "Node.h"
#include "Robot.h"
#include "CalNodeData.h"

/*constructor*/
Node::Node(int name_of_node) {
	this->name=name_of_node;
	this->isLeaf=true;
	this->state=not_visited;
	this->my_father=NULL;
	this->next_status= not_visited;
	this->my_level=-1;
	this->isDespliteLevel=false;
	this->myLevel_under_desplite=false;
	this->vis=false;
	this->i=0;

}
/*********************************************
*this function add son pointer to the node's
*sons vector
*********************************************/
void Node::add_Son(Node* s){

	this->mySans.push_back(s);	
}
/*********************************************
*this function change the nodes level to be
*the max level of the son's node +1 
*********************************************/
void Node:: changeMyLevel(){

	vector<Node*>::iterator it;
	
	if(this->get_isLeaf() ){
		this->my_level=0;

	}
	else{

		for (it = mySans.begin();it != mySans.end(); ++it){
			if(this->my_level==-1){
				this->my_level=(*it)->getLevel()+1;
			}
			else{
				if(this->my_level < (*it)->getLevel()+1){
					this->my_level=(*it)->getLevel()+1;
				}
			}
		}
	}
}

/*********************************************
*this function set the nodes 
*myLevel_under_desplite member to true if the
*node's level is under desplite level
*********************************************/
void  Node::set_myLevel_under_desplite(){
	this->myLevel_under_desplite=true;
}
/*********************************************
*this function return true is the nodes
level is under seplite the false otherwise
*********************************************/
bool Node::get_myLevel_under_desplite(){
	return this->myLevel_under_desplite;
}
/*********************************************
*this function return the node's level
*********************************************/
int Node::getLevel(){
	return this->my_level;
}
/*********************************************
*this function return true is the node's level
*is a desplite node and false otherwise
*********************************************/
bool Node::isLevelDesplite(){
	return this->isDespliteLevel;
}
/*********************************************
*this function initialize the father pointer
*of the node
*********************************************/
void Node::add_father(Node* f){
	this->my_father=f;
}
/*********************************************
*this function return true if the node if 
*leaf and false otherwise
*********************************************/
bool Node::checkIfTheNodeIsLeaf( Node* n){
	if(n->mySans.empty())
		return true;
	else
		return false;
}
/*********************************************
*this function set the isLeaf memeber to true
*********************************************/
void Node::changeIsLeafToFalse(){
	this->isLeaf=false;
}
/*********************************************
*this function return the current level of the 
*node
*********************************************/
int Node::getCurrentLevel(){
	return this->my_level;
}
/*********************************************
*this function set the isDespliteLevel member
*to true.
*********************************************/
void Node::changeToDespliteLevel(){
	this->isDespliteLevel=true;
}
/*********************************************
*this function return the value of isLeaf 
*member
*********************************************/
bool Node::get_isLeaf(){
	return this->isLeaf;
}
/*********************************************
*this function return the name of the node
*********************************************/
int Node::getName(){
	return name;
}
/*********************************************
*this function return the state of the node:
1- the node is visited
2- the node is not visited
3-the node is inhabited
*********************************************/
int Node::get_state(){
	return this->state;
}
/*********************************************
*this function set the state of the node
*********************************************/
void Node::setStatuse(){
	if(this->next_status != reset_status){
		
		this->state=this->next_status;
		
	}
}
/*********************************************
*this function return a pointer to the father's
*node
*********************************************/
Node* Node::getMyFather(){
	return this->my_father;
}
/*********************************************
*this function return the next state of the 
*node 
*********************************************/
int Node::getNextstate(){
	return  this->next_status;
}
/*********************************************
*this function return true if the node has son
*who will not be visited in the  next time of 
*scanning
*********************************************/
bool Node::is_exist_son_who_is_not_will_be_visited_next_time(){
	vector<Node*>::iterator it;

	for (it = mySans.begin();it != mySans.end(); ++it){
		if((*it)->getNextstate() == not_visited){
			return true;
		}
	}
	return false;
}
/*********************************************
*this function return true if we splite allready
*the robots between the sons nodes 
*********************************************/
bool Node::ifIdidSplitAllready(){

	 vector<Robot*>::iterator it;
	if(nextRobotList.front()!=NULL)
	it = find (currentRobotList.begin(), currentRobotList.end(),
	           nextRobotList.front());
	/*if i didnt found some robot from the current
	 robot list  in the next robot list->i did splite*/
	if (it != nextRobotList.end())
		return true;
	else
		return false;
}
/*********************************************
*this function return pointr to son who is 
*current state is not visited  and he
*will not be visited next time
*********************************************/
Node* Node::get_son_who_is_not_visited_yet(){
	vector<Node*>::iterator it;

	for (it = mySans.begin();it != mySans.end(); ++it){
		if((*it)->get_state() == not_visited && 
			(*it)->getNextstate() != inhabited ){
			return *it;
		}
	}
	return NULL;
}

/*********************************************
*this function return pointer to son who is 
*current state is not visited or inhabited
*********************************************/
Node* Node::getSonWithStateInhabitedOrNotVisited(){
	vector<Node*>::iterator it;

	for (it = mySans.begin();it != mySans.end(); ++it){
		if((*it)->get_state() != visited  ){
			return *it;
		}
	}
	return NULL;
}
/*********************************************
*this function return pointer to son how 
*his vis flag is set to false
*********************************************/
Node* Node::getSonWhichIHaventVisYetDfs(){
	vector<Node*>::iterator it;

	for (it = mySans.begin();it != mySans.end(); ++it){
		if((*it)->vis == false){
			return *it;
		}
	}
	return NULL;
}
/*********************************************
*this function return true is the node has 
*sons which in inhabited state
*otherwise return false
*********************************************/
bool Node::is_exisit_son_who_is_inhabited(){
	vector<Node*>::iterator it;
	for (it = mySans.begin();it != mySans.end(); ++it){
		if((*it)->getNextstate() == inhabited){
			return true;
		}
	}
	return false;
}
/*********************************************
*this function return true if there is son
*node how is next robot's list is empty,
*otherwise return false.
*********************************************/
bool Node::existe_son_who_nextRobotlist_is_not_empty(){
	vector<Node*>::iterator it;

	for (it = mySans.begin();it != mySans.end(); ++it){
		if((*it)->getNextRobotListSize() > 0){
			return true;
		}
	}
	return false;
}
/*********************************************
*this function return the node's son vector
*********************************************/
vector<Node*> Node:: get_vector_sons(){
	return this->mySans;
}
void Node::print_my_sons(){
	vector<Node*>::iterator it;

	for (it = mySans.begin();it != mySans.end(); ++it){
		if(it==mySans.end()-1){
			cout<<(*it)->getName();
		}
		else{
			cout<<(*it)->getName()<<",";
		}
	}
}
/*********************************************
*this function return the number of not visited 
*sons of the node
*********************************************/
int Node::numOfNotVisitedChildren(){
	vector<Node*>::iterator it;
	int count=0;
	for (it = mySans.begin();it != mySans.end(); ++it){
		if((*it)->get_state()==not_visited && 
			(*it)->getNextstate()== not_visited )
		{
			count++;
		}

	}
	return count;
}
/*********************************************
*this function return the size of the node's
*next robot's list
*********************************************/
int Node::getNextRobotListSize(){
	return this->nextRobotList.size();
}
/*********************************************
*this function return the current vector
*list
*********************************************/
vector<Robot*> Node::getCurrentRobotList(){
	return this->currentRobotList;
}
/*********************************************
*this function return the next robots list of 
*the node
*********************************************/
vector<Robot*> Node::getNextRobotList(){
	return this->nextRobotList;
}
/*********************************************
*this function set the next robot node to
*be my father
*********************************************/
void Node::moveAllRobotsToMyfather(Robot *r){
	Node* father=this->getMyFather();
	if(father != NULL){
		father->updateNextRobotList(r); //add to the father list  robot r
		/*remove the robot from the list of robots
		i can give becouse i just gave this robot*/
		this->removeRobotFromremoveRobotFromMyRobotsWhichIcanGiveList(r);
		/*if the robot r was in my next robot list before the calling to
		this function i remove it*/
		this->removeRobotFromMyNextList(r); 
		r->setNextNode(father);
	}
}
/*********************************************
*this function moving the "r" robot  to
* my father node'and return a pointer to the
*node who get the robot
*********************************************/
Node* Node::moveRobotsToNotVisitedSon_(Robot *r,Node* son){
	// add to the son next  robot list  the robot r + cal the son next state
	son->updateNextRobotList(r); 
	r->setNextNode(son);
	this->removeRobotFromremoveRobotFromMyRobotsWhichIcanGiveList(r);
	this->removeRobotFromMyNextList(r);

	return son;
}
/*********************************************
*this function gets two list and 
*copy the source list to the dest list
*********************************************/
void Node::copyRobotLists(vector<Robot*>& L_source,vector<Robot*>& L_dest){
	vector<Robot*>::iterator it;
	L_dest.clear();

	for (it = L_source.begin();it != L_source.end(); ++it){
		L_dest.push_back((*it));
	}

}
/*********************************************
*this function initalize the RobotsWhichIcanGive
*list by the currentRobots list 
*********************************************/
void Node::initRobotsWhichIcanGiveList(){
	copyRobotLists(currentRobotList,RobotsWhichIcanGive);
}
/*********************************************
*this function set the current state
*********************************************/
void Node::copyState(int s){
	this->state=s;
}
/*********************************************
*this function add robot "r" tp the current robot
*list 
*********************************************/
void Node::addRobotToCurrentRobotList(Robot *r){
	this->currentRobotList.push_back(r);
}
/*********************************************
*this function add robot "r" tp the next robot
*list 
*********************************************/
void Node::addRobotToNextRobotList(Robot *r){
	this->nextRobotList.push_back(r);	
}
/*********************************************
*this function return true is the node appears
*in the list and false otherwise
*********************************************/
bool Node::isNodeAllreadyExistInList(vector<Node*> list,Node* node){
	 vector<Node*>::iterator it;

  it = find (list.begin(), list.end(), node);
  if (it != list.end())
    return true;
  else
    return false;
}
/*********************************************
*this function remove the "r" robot from the
*node's next list
*********************************************/
void Node::removeRobotFromMyNextList(Robot *r){
	vector<Robot*>::iterator it;
	int i=0;
   for (it = nextRobotList.begin();it != nextRobotList.end(); ++it){
	   
	   if((*it)->getName()==r->getName()){
		   nextRobotList.erase(nextRobotList.begin()+i);
		   break;
	   }
	   i++;

   }
}
/*********************************************
*this function remove the "r" robot from the
*node's RobotsWhichIcanGiveList 
*********************************************/
void Node::removeRobotFromremoveRobotFromMyRobotsWhichIcanGiveList(Robot *r){
	vector<Robot*>::iterator it;
	int i=0;
   for (it = RobotsWhichIcanGive.begin();it != RobotsWhichIcanGive.end(); ++it){
	   
	   if((*it)->getName()==r->getName()){
		   RobotsWhichIcanGive.erase(RobotsWhichIcanGive.begin()+i);
		   break;
	   }
	   i++;
   }
}
/*********************************************
*this function move robot "r" to the son
* node (from the input)
*********************************************/
Node* Node::moveRobotsToNotVisitedSonExceptOne(Robot *r,Node* son){
	Node *currentNode=r->getCurrentNode();
	if(getNextRobotListSize() >= 1){//if the  next robot list is not empty
		Node *n=currentNode->moveRobotsToNotVisitedSon_(r,son);
	
		return n;
	}
	else{
		
			currentNode->addRobotToNextRobotList(r);// add the robot to me 
			r->setNextNode(currentNode); // this robot will stay in me next time
			return NULL;
		
	}
}
/*********************************************
*this function set next node of the robots
*as this node
*********************************************/
void Node::RobotStayNextTime(Robot *r){ 
	this->addRobotToNextRobotList(r);
	r->setNextNode(this);
	
}
/*********************************************
*this function move all my robots to my fater
*except ont robot
*********************************************/
void Node::moveAllRobotsToMyFatherExceptOne(Robot *r){
	if(getNextRobotListSize() >= 1){//if the  next robot list is not empty
		// r in in the current list and there for i move it to my father next list
		moveAllRobotsToMyfather(r); 
	}
	else{
		addRobotToNextRobotList(r); // add the robot to me 
		r->setNextNode(r->getCurrentNode()); // this robot will stay in me next time
	}
}
/*********************************************
*this function update the node's next
*robot list by adding robots "r" to the list
*********************************************/
void Node::updateNextRobotList(Robot *r){
	addRobotToNextRobotList(r);
	
}
/*********************************************
*this function switch between the current 
*node data and the next node data
*********************************************/
void Node::changeData(){
	if(this->getNextRobotListSize() != 0){
		copyRobotLists(this->nextRobotList,this->currentRobotList);
		copyRobotLists(this->currentRobotList,this->RobotsWhichIcanGive);
	}
	else{
		this->currentRobotList.clear();
	}

	copyState(this->next_status);
	this->nextRobotList.clear();
	
	this->next_status=this->state; 
	if(this->state == 3)
		calMyAcentorsNextState(this->my_father);//change my acentor to inhabited if i am inhabited 
	
}
/*********************************************
*this function set the next sate of the node
*********************************************/
void Node::setNextState(int s){
	this->next_status=s;
}
/*********************************************
*this function calculate what
*should be te next state of the node
*********************************************/
void Node::calNextState(Node *node){
	if((node->checkIfTheNodeIsLeaf(node)==true) &&
		((node->getNextRobotListSize() > 0) || (node->get_state() == visited))){
		node->setNextState(visited);
	}
	else if(node->is_exist_son_who_is_not_will_be_visited_next_time() == true && node->get_state()==not_visited){
		
		node->setNextState(not_visited);
	}
	//all the sons is  visited or inhabited
	else if (node->get_son_who_is_not_visited_yet() == NULL || 
		node->is_exist_son_who_is_not_will_be_visited_next_time() ==false ){
			// i have sons who is inhabited and also visited
		if(node->is_exisit_son_who_is_inhabited()){ 
			node->setNextState(inhabited);
		}
		//all the sons is visited but there is robots in them next time
		else if(node->existe_son_who_nextRobotlist_is_not_empty() ){
			node->setNextState(inhabited);
		
		}
		else { // all the sons are not visited and no one of them has robots
			node->setNextState(visited);
		}
	}
		
}
/*********************************************
*this function calculate the next
*state of the acentors 
*********************************************/
void Node::calMyAcentorsNextState(Node* node){
	if(node==NULL){
		return;
	}
	calNextState(node);
	node->copyState(node->getNextstate());
	
	node->setNextState(node->get_state()); 
	calMyAcentorsNextState(node->getMyFather());

}
/*********************************************
*this function return pointer to robot which
*the node can give
*********************************************/
Robot* Node::getRobot(){
	if( this->RobotsWhichIcanGive.size()>0){
		
		return (this->RobotsWhichIcanGive.front());
	}
	else{
		return NULL;
	}
}
/*********************************************
*this function return true if the robot "r"
*is in the list and false otherwise
*********************************************/
bool Node::FindRobotinList(Robot* r,vector<Robot*> vec){
	 std::vector<Robot*>::iterator it;

  it = find (vec.begin(), vec.end(), r);
  if (it != vec.end())
    return true;
  else
    return false;
}
/*********************************************
*this function return pointer to robot
*********************************************/
Robot* Node::getNextRobot(int i){
	
	Robot *r;
	size_t size=this->RobotsWhichIcanGive.size();
	
	if(i < this->RobotsWhichIcanGive.size()){
		
		r= this->RobotsWhichIcanGive.at(i);
	}
	else{
		
		r=NULL;
	}
	return r;
}
/*********************************************
*this function sort the sons in the sons
*list of the node
*********************************************/
bool sortfunc (Node* i,Node* j) { 
	CalNodeData map;
	int numOfNotVisitedSons_i=map.CalHowMuchNotVisitedSonsInMySubTree(i);
	int numOfNotVisitedSons_j=map.CalHowMuchNotVisitedSonsInMySubTree(j);
	return (numOfNotVisitedSons_i > numOfNotVisitedSons_j); 
}

/*********************************************
*this function desplited the robot between the
*sons nodes eaqualy .
*********************************************/
Node* Node::DespliteRobots(Robot* rob,Node* son){ 
	 //one robot stay in father and the other desplite between the children equaly
	((son)->addRobotToNextRobotList(rob)); //add the robot to the sons next list 
	rob->setNextNode((son));// put the son to be the next node of the robot
										
	if(son!=this){
		this->removeRobotFromremoveRobotFromMyRobotsWhichIcanGiveList(rob);
		this->removeRobotFromMyNextList(rob);
		return  son;
	}
	else//I gave to me the robot becouse I will not have robots next time
		return NULL;
}
/*destructor*/
Node::~Node() {}

