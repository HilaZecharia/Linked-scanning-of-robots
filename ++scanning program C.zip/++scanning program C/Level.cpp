
#include "Level.h"

Level::Level() {
	isItDespliteLevel=false;
	numOfLevel=-1;
}
int Level::getLevel(){
	return numOfLevel;
}
void Level::changeToDespliteLevel(){
	this->isItDespliteLevel=true;
}
bool Level::isDespliteNode(){
	return isItDespliteLevel;
}

void Level::setLevel(int l){

	numOfLevel=l;

}


Level::~Level() {}

