#include "ReadFromFile.h"

/*constructor*/
ReadFromFile::ReadFromFile(Graph *g)
{
	this->g=g;
}
/*********************************************
*this function read the graph from the input file
*********************************************/
void ReadFromFile::readInputFile(char* path){
  string line;
  ifstream myfile (path);
  if (myfile.is_open())
  {
    while ( getline (myfile,line) )
    {
		std::size_t index=line.find(']');
		string fater_node=line.substr (1,index-1);
		std::size_t  endIndex=line.length()-(index+2);
		 string son_str=line.substr((index+2),endIndex-1);
		 if(son_str!=""){
			
			 vector<int> sons=parseSonsString(son_str);
			 //add to the graph new edge 
			 for(int i = 0; i < sons.size(); ++i)

				 g->addEdge(g->create_New_Node(atoi (fater_node.c_str())),g->create_New_Node( sons[i]));
		 }
    }
    myfile.close();
  }
  //if we cannot openning the file
  else{ 
	cout << "Unable to open  input file"<<endl;
	exit(1);
  } 

}

/*********************************************
*this function splite the line we just read
*from the file to tokens separated by ','
*********************************************/
vector<string> split(string str, char delimiter) {
  vector<string> internal;
  stringstream ss(str); // Turn the string into a stream.
  string tok;
 
  while(getline(ss, tok, delimiter)) {
    internal.push_back(tok);
  }
 
  return internal;
}

/*********************************************
*this function parsing the node's sons string
*from the input file
*********************************************/
vector<int> ReadFromFile::parseSonsString(string son_str){
	
   std::vector<std::string> v;
   std::vector<int> v_int_vector;

    vector<string> sep = split(son_str, ',');
	v_int_vector=convertToInt( sep);

	return v_int_vector;
}
/*********************************************
*this function convert string to integer
*and return the ingeter number
*********************************************/
vector<int> ReadFromFile::convertToInt(vector<string> v){
	vector<int> intVec;
	for(int i = 0; i < v.size(); ++i){
		  int num=atoi(v[i].c_str());
		  //int num = stoi (v[i]);
		  intVec.push_back(num);

	}
	return intVec;
}



