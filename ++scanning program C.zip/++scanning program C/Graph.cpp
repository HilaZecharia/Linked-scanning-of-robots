#include "Graph.h"

/*consructor*/
Graph::Graph() {}
/*********************************************
*this function find specific node by name in 
*the node's vector of the graph
*********************************************/
Node* Graph:: findNodeInVec(int name){
	vector<Node*>::iterator i;
	//search the node if exist allready
	for (i = adj.begin(); i != adj.end(); ++i){

		if((*i)->getName() == name){
		    return *i;
		}

	}
	return NULL;
}
/*********************************************
*this function return pointer to the root of 
*the tree
*********************************************/
Node* Graph::getRoot(){
	vector<Node*>::iterator i;
	//search the node if exist allready
	for (i = adj.begin(); i != adj.end(); ++i){
		//find the root of the tree
		if((*i)->getMyFather()==NULL){
			this->root=*i;
			break;
		}
	}
	return this->root;
}

/*********************************************
*this function create the nodes of the graph
*and return pointer to the node who just created
*********************************************/
Node* Graph::create_New_Node(int name){

	//search the node if exist allready
	Node* i=findNodeInVec(name);
	if(i)
		return i;
	else
	{
		Node* n=new Node(name);
		adj.push_back(n);//add the node to the vector
		return n;
	}
}
/*********************************************
*this function get desplited level and add it
*to the graph
*********************************************/
void Graph::add_desplit_levels(int l){
	desplit_levels_list.push_back(l);
}

/*********************************************
*this function add the edges in the graph,
*it sets the son his father, and the father add
*the son to his son's vector
*********************************************/
void Graph:: addEdge(Node* father, Node* son){
	Node* n=findNodeInVec(father->getName());
	n->add_Son(son);// Add w to v's list.
    n->changeIsLeafToFalse(); //n is not a leaf node any more

	son->add_father(father); // Add father v to son w


}
/*********************************************
*this function set the node's levels recursively
*it cames down to the leaves and set its level
*to zero,when the recurssion come back its set
*the other nodes level to be 1 move then the son's
*level
*********************************************/
void Graph::DFSUtilLevel(Node* v)
{
     // Mark the current node as visited and print it
	if(v->get_isLeaf()){
		leaves.push_back(v); //add the leaf to the leaves list
		(v)->changeMyLevel(); //set the leaf level to 0
		checkIfLevelNodeDesplite(v);
		v->vis = true;
		return;
	}
 
    // Recur for all the vertices adjacent to this vertex
	Node *s=v->getSonWhichIHaventVisYetDfs();
	while(s!= NULL){
		 DFSUtilLevel(s);
		 s=v->getSonWhichIHaventVisYetDfs();	 

	}
		 (v)->changeMyLevel();
		 checkIfLevelNodeDesplite(v);
		 v->vis=true;//flasg that we calculate allready this vector level		
}
/*********************************************
*this function printing the graph
*********************************************/
void Graph::printLevel(){
cout<<"num of nodes in g:"<<adj.size()<<endl;
	vector<Node*>::iterator it_Nodes;
	//search the node if exist allready
		for (it_Nodes = adj.begin();it_Nodes != adj.end(); ++it_Nodes){

			cout<<"Node:"<<(*it_Nodes)->getName()<<"  sons:";
			(*it_Nodes)->print_my_sons();

			if((*it_Nodes)->getMyFather())
					cout<<"  my father:"<<((*it_Nodes)->getMyFather()->getName())<<
					"  my level:"<<(*it_Nodes)->getLevel();
			else
				cout<<"   my father: null"<<"  my level:"<<(*it_Nodes)->getLevel();

			cout<<'\n';
		}

}
/*********************************************
*this function is a factor functor for the sort
*the node's vector
*********************************************/
bool myfunction (Node* n,Node* t) { 
	return (n->getName() < t->getName()); 
}
/*********************************************
*this function sort the vector node's by the
*node's name
*********************************************/
void Graph::sortNodesVector(){

	 std::sort (adj.begin(), adj.end(), myfunction);
}
/*********************************************
*this function check if the node's level is 
*desplite node or not, if it is we set
*at the node desplite flag to true,and if not 
*to false
*********************************************/
void Graph::checkIfLevelNodeDesplite(Node* n){
	vector<int>::iterator i;
	int node_level=n->getLevel();
	for (i = desplit_levels_list.begin(); i != desplit_levels_list.end(); ++i){
		if(node_level == (*i)){
			n->changeToDespliteLevel();

		}
		else if(node_level < (*i)){
			n->set_myLevel_under_desplite();
		}
	}

}

/*********************************************
*this function call the function DFSUtilLevel
*to initalize the graph nodes level
*********************************************/
void Graph::init_levels_in_Graph(Node* v){
	DFSUtilLevel(v);
}
/*********************************************
*this function return the leaves vector of
*the graph
*********************************************/
vector<Node*> Graph::getTheLeavesInTheGraph(){
	return this->leaves;
}

/*********************************************
*this function return the nodes vector of
*the graph
*********************************************/
vector<Node*> Graph::getNodeVector(){
	return this->adj;
}
/*********************************************
*this function check if the node "n" is in 
*desplite level, if it s return true' otherwise 
*return false
*********************************************/
bool Graph::check_if_the_Node_in_desplite_level(Node* n){
	bool b;
	//return true if the node is in desplite level and false otherwise
	b= std::find(desplit_levels_list.begin(), desplit_levels_list.end(), n->getCurrentLevel()) != desplit_levels_list.end() ;
	return b;
}
/*destructor*/
Graph::~Graph() {}

