#include "Robot.h"
#include "Node.h"

/*constructor*/
Robot::Robot(int n)
{
	name=n;
	this->current_node=NULL;
	this->next_node=NULL;
}
/*********************************************
*this function set the current robot's node
*********************************************/
void Robot::setCurrentNode(Node *n){
	this->current_node=n;
}
/*********************************************
*this function return a pointer to the 
*robot's current node
*********************************************/
Node* Robot::getCurrentNode(){
	return this->current_node;
}
/*********************************************
*this function set the next robot's node
*********************************************/
void Robot::setNextNode(Node *n){
	this->next_node=n;
}
/*********************************************
*this function return a pointer to the 
*robot's next node
*********************************************/
Node* Robot::getNextNode(){
	return this->next_node;
}
/*********************************************
*this function return the robot's name
(its number)
*********************************************/
int Robot::getName(){
	return this->name;
}
/*********************************************
*this function return the level of the current
*node of the robot
*********************************************/
int Robot::getCurrentNodeLevel(){
	return this->current_node->getCurrentLevel();
}
/*********************************************
*this function return the state of the current
*node
*********************************************/
int Robot::getCurrentNodeState(){
	return this->current_node->get_state();
}
/*********************************************
*this function return the current node's name
*********************************************/
int Robot::getCurrentNodeName(){
	return this->current_node->getName();
}
/*destructor*/
Robot::~Robot(){}
