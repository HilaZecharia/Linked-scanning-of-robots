
#ifndef GRAPH_H_
#define GRAPH_H_
#include<iostream>
#include<vector>
#include<list>
#include <algorithm>
#include <map>
#include "Node.h"

using namespace std;

class Graph {
	private:
		vector<Node*> adj;
		vector<int> desplit_levels_list;
		vector<Node*> leaves;
		Node* root;

public:
	Graph();
	Node* getRoot();
	void addEdge(Node* v, Node* w);
	void add_desplit_levels(int l);
	Node* findNodeInVec(int name);
	Node* create_New_Node(int name);
	void scan_graph(Node* root);
    bool check_if_the_Node_in_desplite_level(Node* n);
    void DFSUtilLevel(Node* root);
    void init_levels_in_Graph(Node *root);
    void setMyAncestorsLevel(Node* n);
    void DFS(Node* root);
    vector<Node*> getTheLeavesInTheGraph();
	void checkIfLevelNodeDesplite(Node* n);
	vector<Node*> getNodeVector();
	void addDesplitLevel(int l);
	virtual ~Graph();
	void set_myLevel_under_desplite();
	void sortNodesVector();
	void printLevel();
};

#endif /* GRAPH_H_ */
