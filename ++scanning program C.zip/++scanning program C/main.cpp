
#include <iostream>
#include "CalFutureGraph.h"
#include "ReadFromFile.h"
#include "CreateRandomGraph.h"
#include "Graph.h"


using namespace std;
int main(int argc, char* argv[]) {
	
	//create the graph
	  Graph *g=new Graph();
	  Cal_Future_Graph c;
	  int numOfRobots;
	
	  //get the argumants from the main

	  if (argc < 3){//if the use enter less then 3 argumants
		  cout<<"you need to Enter 3 Argumants in that order:"<<endl;
		  cout<<"first:path to the graph file"<<endl;
		  cout<<"second:number of robots"<<endl;
		  cout<<"third: a list of all the desplite's levels"<<endl;

		  return 0;
	  }
	  else //the user enter 3 argumants correctly correctly
	  {

	    char* pathOfFile = argv[1];
	    numOfRobots = atoi(argv[2]);
	    ReadFromFile read(g);

	    //call to the read from file function
	    unsigned int i;
	    size_t size =argc - 1;
	   //go over the desplite level list
	   for(i=3;i<=size;i++){
		int despliteLevel=atoi(argv[i]);
		g->add_desplit_levels(despliteLevel);

	}
	read.readInputFile(pathOfFile);

	   }
	    //write the graph to file for visual presentation
		c.writeGraph(g);
		g->sortNodesVector();
		Node* root=g->getRoot();
		//if the root is not null
		if(root){
			g->init_levels_in_Graph(root);
			c.initRobotList(numOfRobots,root);//initialize the robots list
			//start scanning the graph
			c.runAlgo(g,root);
			cout<<"done"<<endl;
		}
		//the root is null
		else {
			cout<<"the root is null"<<endl;
		}



    return 0;
}




