
#ifndef NODE_H_
#define NODE_H_
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>  

class Robot;
class MapNodeData;

#define reset_status 0
#define visited 1
#define not_visited 2
#define inhabited 3


using namespace std;
class Node {
private :
	int name;
	vector<Node*> mySans;	
	int state;
	Node* my_father;
	vector<Robot*> currentRobotList;
	vector<Robot*> nextRobotList;
	int my_level;
	bool isDespliteLevel;
	bool myLevel_under_desplite;
	bool isLeaf;
	int next_status;

public:

	int i;
	vector<Robot*> RobotsWhichIcanGive; 
	bool vis;
	Node(int name);
	int getName();
	int get_state();
	void setStatuse();
	void setNextState(int s);
	Node* getMyFather();
	vector<Node*> get_vector_sons();
	void add_Son(Node* s);
	void add_father(Node* f);
	void print_my_sons();
	int getLevel();
	void initRobotsWhichIcanGiveList();
	int getCurrentLevel();
	void changeToDespliteLevel();
	bool isLevelDesplite();
	void set_myLevel_under_desplite();
	bool get_myLevel_under_desplite();
	void changeMyLevel();
	bool checkIfTheNodeIsLeaf( Node* n);
	void changeIsLeafToFalse();
	bool get_isLeaf();
	int getNextRobotListSize();
	void calMyAcentorsNextState(Node* node);
	Node* get_son_who_is_not_visited_yet();
	Node* getSonWithStateInhabitedOrNotVisited();
	bool is_exist_son_who_is_not_will_be_visited_next_time();
	int numOfNotVisitedChildren();
	bool is_exisit_son_who_is_inhabited();
	bool existe_son_who_nextRobotlist_is_not_empty();
	int getNextstate();
	bool ifIdidSplitAllready();
	vector<Robot*> getCurrentRobotList();
	vector<Robot*> getNextRobotList();
	void addRobotToNextRobotList(Robot *r);
	void addRobotToCurrentRobotList(Robot *r);
	void moveAllRobotsToMyfather(Robot *r);
	Node* moveRobotsToNotVisitedSon_(Robot *r,Node* son);
	void copyRobotLists(vector<Robot*>& L_source , vector<Robot*>& L_dest);
	void copyState(int s);
	Node* DespliteRobots(Robot* rob,Node* son);
	Node* moveRobotsToNotVisitedSonExceptOne(Robot *r,Node* son);
	void RobotStayNextTime(Robot *r);
	void moveAllRobotsToMyFatherExceptOne(Robot *r);
	void updateNextRobotList(Robot *r);
	void changeData();
	void calNextState(Node *node);
	Node* getSonWhichIHaventVisYetDfs();
	bool isNodeAllreadyExistInList(vector<Node*> list,Node* node);
	void removeRobotFromMyNextList(Robot *r);
	void removeRobotFromremoveRobotFromMyRobotsWhichIcanGiveList(Robot *r);
	bool FindRobotinList(Robot* r,vector<Robot*> list);
	Robot* getRobot();
	Robot* getNextRobot(int i);
	virtual ~Node();
};

#endif /* NODE_H_ */
