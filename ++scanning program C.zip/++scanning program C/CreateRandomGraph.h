#pragma once
#include "Node.h"
#include "Graph.h"



#include <cstdlib>
 class CreateRandomGraph
{
private:
	int brunch_factor;
	int deep;
	int random_numberTreshHold;
	Graph *graph;

public:
	CreateRandomGraph(int brunch_factor,int deep,Graph *g,int treshHold);
	Node* createRoot();
	void createSonsRandomly(Node *n);
	void BuildRandomGraph(Node *node,int MAxDeep,int currentDeep);
};

