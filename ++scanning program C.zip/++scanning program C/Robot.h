class Node;


#define visited 1
#define not_visited 2
#define inhabited 3

class Robot
{
	private:
		Node* current_node;
		Node* next_node;
		int name;
	
	public:
		Robot(int name);
		void setCurrentNode(Node *n);
		Node* getCurrentNode();
		void setNextNode(Node* n);
		Node* getNextNode();
		int getName();
		int getCurrentNodeLevel();
		int getCurrentNodeState();
		int getCurrentNodeName();
		~Robot();
};

