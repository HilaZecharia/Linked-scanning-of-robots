
#include "CalFutureGraph.h"
/* global variables */
int NUM_OF_ROBOTS;
bool IS_CHANGE=false;

/*constructor*/
Cal_Future_Graph::Cal_Future_Graph() {
	time=0;
	output="";
	out_put_file="";
}
/*********************************************
*this function create the robots list
*and set them in the root of the tree
*********************************************/
void Cal_Future_Graph::initRobotList(int numOfRobots,Node* n){
	int i;
	for(i=1;i<=numOfRobots;i++){
		Robot* r=new Robot(i);
		r->setCurrentNode(n);
		n->addRobotToCurrentRobotList(r);
		RobotList.push_back(r);
	}
	n->initRobotsWhichIcanGiveList();
	NUM_OF_ROBOTS=numOfRobots;//intialize the global variable
}

/*********************************************
*this function run the scanning algorithem
*on the graph using uristics for making the
*scaning more efficient
*********************************************/
void Cal_Future_Graph::runAlgo(Graph *g,Node *root){
		Nodes.push_back(root); 
		print_graphToOutPutFile(g);
		update_output_string(g,true);
		IS_CHANGE=true;
	while(root->get_state() != visited && checkConnectivity()==true && IS_CHANGE==true){
		IS_CHANGE=false;//init the IS_CHANGE flag before calculate the scanning in the next time
		time++;
		
		goOverRobotsAndScan(Nodes);
		moveRobots();// change between the curent node to the next node of  the robot
		print_graphToOutPutFile(g);
		update_output_string(g,false);
		if(root->get_state() != visited){ //not printed enter in the end of the output
			output+='\n';	
		}

		SortRobotList();
		initNodeListForNextSacn();
	}

	if(root->get_state() == visited){
		WriteOutputToFile writeFile;
		writeFile.WriteToFile(output,"scanning_forVisual_presentation.txt");
		//copy out_put_file without the last '\n' in the end
		writeFile.WriteToFile((out_put_file.substr(0, out_put_file.size()-1)),"output_scaning.txt");
		writeDespliteNode(g->getNodeVector());
	}
	else 
		cout<<"robots loose communication"<<endl;

}
/*********************************************
*this function concate the data of the scanning
*to string  for the file
*********************************************/
void Cal_Future_Graph::update_output_string(Graph *g,bool b){
	output+="$$$$$$$$$$$$$$$$$$$$";
	cout<<"$$$$$$$$$$$$$$$$$$$$$$$$$$$"<<endl;
	output+='\n';
	output+="time:"+convertIntToString(time)+'\n';
	cout<<"time:"<<time<<endl;
	print_graph(g);
	print_graphToFileVisual_presentation(g);
	output+="********************";
	cout<<"**************************"<<endl;
	if(b){
	   output+='\n';
	}	
	
}
/*********************************************
*this function scanning all the nodes which
*contains robots
*********************************************/
void Cal_Future_Graph::goOverRobotsAndScan(vector<Node*> list){
	vector<Node*>::iterator i;
	for (i = list.begin();i != list.end(); ++i){
		scanNodeWithRobotsOnly(*i);
	}
}
/*********************************************
*this function save in string variable
*the names of all the nodes which is in 
*desplite level 
*********************************************/
void Cal_Future_Graph::writeDespliteNode(vector<Node*> vec){
	vector<Node*>::iterator it;
	WriteOutputToFile writeFile;
	string s="";
	string sub="";
	for (it = vec.begin();it != vec.end(); ++it){
		if((*it)->isLevelDesplite()){
			string num=convertIntToString((*it)->getName());
			s+=num+",";
		}
	}
	//remove the last ","
	s=s.substr(0, s.size()-1);
	//write to file the nodes you saved
	writeFile.writeNodeDespliteToFile(s);
}
/*********************************************
*this function copy the source list to the 
*destination list
*********************************************/
void Cal_Future_Graph::copyRobotLists(vector<Robot*>& L_source,vector<Robot*>& L_dest){
	vector<Robot*>::iterator it;
	L_dest.clear();

	for (it = L_source.begin();it != L_source.end(); ++it){
		L_dest.push_back((*it));
	}

}
/*********************************************
*this function add nodev to the scanning nodes
*list (whch not exist allready in the list)
*********************************************/
void Cal_Future_Graph::addNodeToScanAgain(Node *n){
	vector<Node*>::iterator it;

  it = find (scanAgainSons.begin(), scanAgainSons.end(), n);
  if (it == scanAgainSons.end())
	  scanAgainSons.push_back(n);
}
/*********************************************
*this function calculate which son need more
*robots and return a pointer to this son
(for nodes which is not in desplite level)
*********************************************/
Node* Cal_Future_Graph::returnSonToGiveRobotTo(Node* currentNodeOfRobot){
	CalNodeData map ;
	map.initVectorSonsWhoNeedRobots(currentNodeOfRobot);
	if(map.CheckIfVectorIsEmpty()==false){
		
		Node* son=map.get_son_to_give_robots();
		return son;
	}
	else
		return NULL;

}
/*********************************************
*this function calculate which son need more
*robots and return a pointer to this son
(for node in desplite level)
*********************************************/
Node* Cal_Future_Graph::DespliteReturnSonToGiveRobotTo(Node* currentNodeOfRobot){
	Node *son=NULL;
	CalNodeData map ;
	if(currentNodeOfRobot->getNextRobotListSize()==0)
		return currentNodeOfRobot;
	else{
		map.initVectorSonsWhoNeedRobots(currentNodeOfRobot);
		//if the node has more not visited sons to give them robots
		while(map.CheckIfVectorIsEmpty()==false ) 
		{
			// if i need to go over again my sons and gave them robots 
			if(currentNodeOfRobot->i > (int)(currentNodeOfRobot->get_vector_sons().size())-1){ 
				currentNodeOfRobot->i=0;
			}
			son=(currentNodeOfRobot-> get_vector_sons()).at(currentNodeOfRobot->i);
			
			if(map.checkIfSonNeedsMoreRobots(son)){
				(currentNodeOfRobot->i)+=1;	
				break;		
			}
			else
				(currentNodeOfRobot->i)+=1;	
		}
	
		return son;
	}
}
/*********************************************
*this function go over the robots in the nodes
*and calculte its next move in the scanning 
*on the next time
*********************************************/
void Cal_Future_Graph::scanNodeWithRobotsOnly(Node *currentNodeOfRobot){
	vector<Robot*>::iterator r;
	vector<Robot*> list=currentNodeOfRobot->RobotsWhichIcanGive;
	//bool flag_split=false;
	bool flagDespliteRobots=false;
	CalNodeData map ;
	Node *son;
	//go over the robotsin the current node we scanning 
	for (r = list.begin();r != list.end(); ++r)
	{
		if(!currentNodeOfRobot->isLevelDesplite() )//if not desplite node
			son=returnSonToGiveRobotTo(currentNodeOfRobot);
		else//if desplite node
			son= DespliteReturnSonToGiveRobotTo(currentNodeOfRobot);
		    // if te current state of the current node is visited
			if((currentNodeOfRobot->get_state() == visited ) &&
				(currentNodeOfRobot->get_son_who_is_not_visited_yet() == NULL) ){ 

				if(currentNodeOfRobot->getMyFather()!=NULL){
					currentNodeOfRobot->moveAllRobotsToMyfather(*r) ;
				}
				else{
					//All robots from from node stops 
					currentNodeOfRobot->RobotStayNextTime(*r); 
				}

			}
			else if((currentNodeOfRobot->get_state() == not_visited) )
			{
				/*if the current node is not visited and it has son who is 
				notvisited now and in the next time the  not visited son
				will not be inhabited we need to move down to the not visited son robots*/
				if(son != NULL && son->getNextstate()!= inhabited)
				{
					if(currentNodeOfRobot->isLevelDesplite() )
					{
							Node *t=currentNodeOfRobot->DespliteRobots(*r,son);

							if(t!=NULL){
								
								scanNodeWithRobotsOnly(t);
							}

					}
					else if(currentNodeOfRobot->getNextRobotListSize() > 1){
						/*I can give all my robots to my sons becouse I 
						will have robot for communication next time */
						Node *v=currentNodeOfRobot->moveRobotsToNotVisitedSon_(*r, son);
						if(v!=NULL){
							scanNodeWithRobotsOnly(v);
							
						}
					}
					// I under desplite level 
					else if(currentNodeOfRobot->get_myLevel_under_desplite() ){ 
						Node *s=currentNodeOfRobot->moveRobotsToNotVisitedSonExceptOne(*r,son);
						if(s!=NULL){
							scanNodeWithRobotsOnly(s);
							
						}
					}
					 // i above  desplite point i.e r.currentNode.level > desplite level
					else{ 
						Node *s;
						if((flagDespliteRobots==true) || 
						   (map.CalHowMuchNotVisitedSonsInMySubTree(son) <(int)(currentNodeOfRobot->RobotsWhichIcanGive).size())){

							/*in the next time i will desplite the robots between my 
							sons so i need to keep robot for communication */
							flagDespliteRobots=true;
							s=currentNodeOfRobot->moveRobotsToNotVisitedSonExceptOne(*r,son);
						}

						else if(chackIfNeedToKeepRobotForCommunication(map,son,currentNodeOfRobot)){
							s=currentNodeOfRobot->moveRobotsToNotVisitedSonExceptOne(*r,son);
						}
						else{
							s=currentNodeOfRobot->moveRobotsToNotVisitedSon_(*r,son);
						}
						if(s!=NULL){
							scanNodeWithRobotsOnly(s);
							
						}

					}
				}
				else
				{
					if(currentNodeOfRobot->getNextRobotListSize()>0 && currentNodeOfRobot->getMyFather()!=NULL ){
						currentNodeOfRobot->moveAllRobotsToMyfather(*r);
					}
					else{
						/* if my sons are inhabited next time i wait for all the robot in their subtree*/
						currentNodeOfRobot->RobotStayNextTime(*r); 
					}
				}
			}
			//  all my sons are visited and my current state is inhabited
			else { 
				//waiting in the splite level (node) until all robot arrivrd to me
				if(currentNodeOfRobot->isLevelDesplite()){

					if(currentNodeOfRobot->getMyFather()!=NULL)
					{
						currentNodeOfRobot->moveAllRobotsToMyFatherExceptOne(*r);
					}
					else{ // the current Node is root
						currentNodeOfRobot->RobotStayNextTime(*r); // All robots from from node stops (break);
					}

				}
				else if( currentNodeOfRobot->getMyFather()!=NULL){ //I not in desplite node

					currentNodeOfRobot->moveAllRobotsToMyFatherExceptOne(*r);

				}
				else{
					currentNodeOfRobot->RobotStayNextTime(*r); //robots go up to the root again 
				
				}
			}
		
		setStateToRobotsNodes((*r)); //set the node new state
		
	}

}

/*********************************************
*this function calculate the position of the 
*robots in the node and check before moving
*robots to some node if
*we need to keep one robot for communication in
*the current node
*if we nwwd to keep robots return true
*otherwise return false
*********************************************/
bool Cal_Future_Graph::chackIfNeedToKeepRobotForCommunication(CalNodeData &map,Node* son,Node* currentNodeOfRobot){
	/*if the father has more robot to give then what the son needs, 
	the father needs to keep robot for communication */
	 if(currentNodeOfRobot->getNextRobotListSize() <= 0 ){
		Node *some_son=currentNodeOfRobot->getSonWithStateInhabitedOrNotVisited();
		if(some_son!= NULL && some_son!= son){
			if(map.CalHowMuchRobotsIWillHaveNextTimenMySubTree(some_son) > 0)
			/* need to keep one robot for communication because I 
			have some son how hase robot in his subtree*/
				return true; 
			else
				return false;
		}
		else	
			return false;
	}
	else
		return false;

}
/*********************************************
*this function sortinf the robots list
*by its state,lavel,and name
*********************************************/
void Cal_Future_Graph::SortRobotList(){
   unsigned int i,j;
   for(i = 0; i < RobotList.size()-1; i++) {
      for(j = 0; j < RobotList.size()-i-1; j++) {

		  if(RobotList[j]->getCurrentNodeLevel() > RobotList[j+1]->getCurrentNodeLevel()) {
         
			  swap(RobotList[j],RobotList[j+1]);
		  }
		  else if(RobotList[j]->getCurrentNodeLevel() == RobotList[j+1]->getCurrentNodeLevel()){
			  //if the robot in the same level but the  j+1 robot is visited and the j robot is not
			  if((RobotList[j+1]->getCurrentNodeState()==visited )&& 
				  (RobotList[j]->getCurrentNodeState()!=visited )){
				  swap(RobotList[j],RobotList[j+1]);
			  }
			  else if((RobotList[j+1]->getCurrentNodeState()==inhabited )&&
				  (RobotList[j]->getCurrentNodeState()==not_visited )){
				  swap(RobotList[j],RobotList[j+1]);
			  }
			  //if the nodes are in the same levels and in the same state sort by their names ascending 
			  else if(RobotList[j+1]->getCurrentNodeState() == (RobotList[j]->getCurrentNodeState() )){
				  if(RobotList[j]->getCurrentNodeName() > RobotList[j+1]->getCurrentNodeName())
					   swap(RobotList[j],RobotList[j+1]);
			  }
		  }

	   }
   }
}

/*********************************************
*this function calculate the current robot's
*node new state and robot's next node new state
*********************************************/
void Cal_Future_Graph::setStateToRobotsNodes(Robot *r){
	Node* currentNodeOfRobot=(r)->getCurrentNode();
	Node* nextNodeOfRobot=r->getNextNode();
	
	if(nextNodeOfRobot!= NULL ){
		 if(currentNodeOfRobot->getName()!= nextNodeOfRobot->getName()){
			 if(currentNodeOfRobot->getCurrentLevel()<= nextNodeOfRobot->getCurrentLevel()){
				currentNodeOfRobot->calNextState(currentNodeOfRobot) ;//calculate it next state
				nextNodeOfRobot->calNextState(nextNodeOfRobot);//calculate it next state
			 }
			 else{
				 nextNodeOfRobot->calNextState(nextNodeOfRobot);
				 currentNodeOfRobot->calNextState(currentNodeOfRobot) ;
			 }

			 IS_CHANGE=true;//the robot is move from one node to other node
		 }
		 else{
			 /* the robot is stay in the same node it was before 
			 so we need to update only one of them and not both*/
			 nextNodeOfRobot->calNextState(nextNodeOfRobot); 
		 }
		 
		 addNodeToNodeWithRobotsList(nextNodeOfRobot);
	}
	else{
		 currentNodeOfRobot->calNextState(currentNodeOfRobot) ;
	}

	 addNodeToNodeWithRobotsList(currentNodeOfRobot);	 
}
/*********************************************
*this function add the node to NodeWithRobots
*list 
*********************************************/
void Cal_Future_Graph::addNodeToNodeWithRobotsList(Node* n){
	vector<Node*>::iterator it;
	bool flag=false;
	if(n!=NULL)
	{
		for (it = NodeWithRobots.begin();it !=NodeWithRobots.end(); ++it){
			if((*it)->getName()==n->getName()){
				flag=true;
				break;
			}
		}
		if(!flag)
			NodeWithRobots.push_back(n);
	}

}
/*********************************************
*this function moving the robots from its 
*current node to the next list by set the next 
*node as the current node
*********************************************/
void Cal_Future_Graph::moveRobots(){
	vector<Node*>::iterator it;
	vector<Robot*>::iterator r;

	for (it = NodeWithRobots.begin();it !=NodeWithRobots.end(); ++it){
		/* swap  in the current Node between the current robot
		list and the curent state to the next*/
		(*it)->changeData(); 
		(*it)->i=0;
	}
	NodeWithRobots.clear();
	for (r = RobotList.begin();r != RobotList.end(); ++r){
		Node* currentNodeOfRobot=(*r)->getCurrentNode();
	    Node* nextNodeOfRobot=(*r)->getNextNode();
		//the next Node in Robot become the current node in robot next time
			(*r)->setCurrentNode(nextNodeOfRobot);
			(*r)->setNextNode(NULL);

	}

}
/*********************************************
*this function save the output of the acanning 
*in string variable which will be writing to 
*file (for Visual presentation)
*********************************************/
void Cal_Future_Graph:: print_graphToFileVisual_presentation(Graph *g){

	vector<Node*>::iterator it_Nodes;
	vector<Robot*>::iterator it_robot;
	vector<Node*> nv=g->getNodeVector();

//search the node if exist allready
	for (it_Nodes =nv.begin();it_Nodes != nv.end(); ++it_Nodes){

		output+="Node:"+convertIntToString((*it_Nodes)->getName());
		output+="#";
		output+="current robots:";
		vector<Robot*> rv=(*it_Nodes)->getCurrentRobotList();
		for (it_robot = rv.begin();it_robot != rv.end(); ++it_robot){

			if(it_robot==rv.end()-1){
				output+=convertIntToString((*it_robot)->getName());
			}
			else{
				output+=convertIntToString((*it_robot)->getName())+",";
			}
		}
		output+="#";
		output+="state node:"+convertIntToString((*it_Nodes)->get_state())+'\n';

	}
}

/*********************************************
*this function save the out_put_file of the scanning 
*in string variable which will be writing to 
*file
*********************************************/
void Cal_Future_Graph:: print_graphToOutPutFile(Graph *g){

	vector<Node*>::iterator it_Nodes;
	vector<Robot*>::iterator it_robot;
	vector<Node*> nv=g->getNodeVector();

	//search the node if exist allready
	for (it_Nodes =nv.begin();it_Nodes != nv.end(); ++it_Nodes){
		out_put_file+="-";
		out_put_file+=" ";
		out_put_file+=convertIntToString(time);
		out_put_file+=" ";
		out_put_file+=convertIntToString((*it_Nodes)->getName());
		out_put_file+=" ";
		vector<Robot*> rv=(*it_Nodes)->getCurrentRobotList();
		if(rv.size() == 0){
			out_put_file+="0";
		}
		else{
			for (it_robot = rv.begin();it_robot != rv.end(); ++it_robot){

				if(it_robot==rv.end()-1){
					out_put_file+=convertIntToString((*it_robot)->getName());
				}
				else{
					out_put_file+=convertIntToString((*it_robot)->getName())+",";
				}
			}
		}
		out_put_file+="\n";
	}
}
/*********************************************
*this function printing the graph
*********************************************/
void Cal_Future_Graph:: print_graph(Graph *g){

	vector<Node*>::iterator it_Nodes;
	vector<Robot*>::iterator it_robot;
	vector<Node*> nv=g->getNodeVector();

	//search the node if exist allready
		for (it_Nodes =nv.begin();it_Nodes != nv.end(); ++it_Nodes){

			cout<<"Node:"<<(*it_Nodes)->getName()<<"  current robots:";
			vector<Robot*> rv=(*it_Nodes)->getCurrentRobotList();
			for (it_robot = rv.begin();it_robot != rv.end(); ++it_robot){
				
				
				cout<<(*it_robot)->getName()<<" ";
			}
			cout<<"  state node:"<<ss((*it_Nodes)->get_state())<<endl;

		}
}
/*********************************************
*this function convert from the const value
*to its meaning 
*********************************************/
string Cal_Future_Graph::ss(int s){
	
	string my_string;
	switch(s){
	case 1:
		my_string="visited";
		break;
	case 2:
		my_string="not visited";
		break;
	case 3:
		my_string="inhabited";
		break;
		
	}

	return my_string;
}
/*********************************************
*this function convert integer number to string
*********************************************/
string Cal_Future_Graph::convertIntToString(int num){
	string Result;//string which will contain the result

	stringstream convert; // stringstream used for the conversion

	convert << num;//add the value of Number to the characters in the stream

	Result = convert.str();
	return Result;

}
/*********************************************
*this function inisialize the Nodes list for
*the next time we scanning the graph
*********************************************/
void Cal_Future_Graph::initNodeListForNextSacn(){
	 vector<Robot*>::iterator it;
	 vector<Node*>::iterator it_node;
	 Nodes.clear();

	for (it = RobotList.begin();it !=RobotList.end(); ++it){
		Node *currentRobotNode=(*it)->getCurrentNode();
		it_node = find (Nodes.begin(), Nodes.end(), currentRobotNode);
	    if (it_node == Nodes.end()) // if the node doesn't appears in the list i add it
			Nodes.push_back(currentRobotNode);
		}
}
/*********************************************
*this function writing the graph to file 
*********************************************/
void Cal_Future_Graph::writeGraph(Graph *g){
	WriteOutputToFile writeFile;
	string str="";
	 vector<Node*>::iterator it_father;
	 vector<Node*>::iterator it_son;
	 vector<Node*> list_father=g->getNodeVector();
	 vector<Node*> list_sons;
	 
	for (it_father = list_father.begin();it_father !=list_father.end(); ++it_father){
		str+="["+convertIntToString((*it_father)->getName())+"]";
		if((*it_father)->get_isLeaf())
			str=str+"["+"]";
		else{
			str+="[";
			list_sons=(*it_father)->get_vector_sons();
			for (it_son = list_sons.begin();it_son !=list_sons.end(); ++it_son){
				if(it_son ==list_sons.end()-1)
					str+=convertIntToString((*it_son)->getName())+"]";
				else
					str+=convertIntToString((*it_son)->getName())+",";
			}
			
		}
		str+='\n';
	}
	//writing the graph to file
	writeFile.writeRandomGraph(str);
}

/*********************************************
*this function check if there is connection between
*th robots  throughout the scan
*********************************************/
bool Cal_Future_Graph::checkConnectivity(){
	size_t size=Nodes.size();
	int i=0;
	Node* lastNode;
	vector<int> arrOfRobots;
	if(size>0)
		lastNode=Nodes.at(size-1);
	else 
		return false; // the node with vector is empty

	for(i=1;i<=NUM_OF_ROBOTS;i++){
		arrOfRobots.push_back(i);
	}
		
	 recurseConnectivity(lastNode,arrOfRobots);
	 if(arrOfRobots.size())
		 return false;
	 else
		 return true;

}
/*********************************************
*this function scanning recurssivly the node
*wihch contains robots and check if there is 
*conncection between the robots
(Tethering component of robots)
*********************************************/
void Cal_Future_Graph::recurseConnectivity(Node *node,vector<int> &arr){

	if(node->getCurrentRobotList().size()==0){
		return ;
	}
	else{

		vector<Node*>::iterator it;
		vector<Node*> vec_children=node->get_vector_sons();
		removeRobots(node->getCurrentRobotList(),arr);

		for (it = vec_children.begin();it != vec_children.end(); ++it){
			recurseConnectivity(*it,arr);
		}


	}

}
/*********************************************
*this function removing robots from the removeFrom
*(the robots name list)
*********************************************/
void Cal_Future_Graph::removeRobots(vector<Robot*> rob_vec,vector<int> &removeFrom){
	 vector<Robot*>::iterator it_rob_vec;
	 vector<int>::iterator it_removeFrom;
	 //the node current robots vector
	 for (it_rob_vec = rob_vec.begin();it_rob_vec != rob_vec.end(); ++it_rob_vec){
	 //the vector of all the robots
		for (it_removeFrom = removeFrom.begin();it_removeFrom != removeFrom.end(); ++it_removeFrom){
	   
		   if((*it_rob_vec)->getName()==(*it_removeFrom)){
			   removeFrom.erase(it_removeFrom);
			   break;//becouse we found that robot and we delete it
		   }
		}
	 }
}
/*destructor*/
Cal_Future_Graph::~Cal_Future_Graph(){}


