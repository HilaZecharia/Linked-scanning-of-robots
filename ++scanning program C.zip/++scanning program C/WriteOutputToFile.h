
#ifndef WRITEOUTPUTTOFILE_H_
#define WRITEOUTPUTTOFILE_H_
#include<iostream>
#include <sstream>
#include <string>
#include <fstream>
using namespace std;
class WriteOutputToFile {
public:
	WriteOutputToFile();
	void WriteToFile(string s,string path);
	void writeNodeDespliteToFile(string s);
	virtual ~WriteOutputToFile();
	void writeRandomGraph(string str);
};

#endif /* WRITEOUTPUTTOFILE_H_ */
