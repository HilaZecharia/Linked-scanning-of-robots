
#ifndef CALFUTUREGRAPH_H_
#define CALFUTUREGRAPH_H_
#include<iostream>
#include<vector>
#include<list>
#include <sstream>
#include<map>
#include<string>
#include <algorithm>

#include "Node.h"
#include "Graph.h"
#include "Robot.h"
#include "CalNodeData.h"
#include "WriteOutputToFile.h"

using namespace std;
class Cal_Future_Graph {
private:
	int time;
	string output;
	string out_put_file;
	vector<Robot*> RobotList;
	vector<Node*> NodeWithRobots;
	vector<Node*> Nodes;
	vector<Node*> scanAgainSons;
public:
	Cal_Future_Graph();
	void SortRobotList();
	string convertIntToString(int num);
	void initRobotList(int numOfRobots,Node* n);
	void runAlgo(Graph *g,Node *root);
	void scanNodeWithRobotsOnly(Node *currentNodeOfRobot);
	void setStateToRobotsNodes(Robot *r);
	void moveRobots();
	void  print_graph(Graph *g);
	void addNodeToNodeWithRobotsList(Node* n);
	void goOverRobotsAndScan(vector<Node*> list);
	void goOver();
	void recur(Node *i);
	void DFSUtil(Node* v, bool visited1[]);
	void addNodeToScanAgain(Node *n);
	void initNodeListForNextSacn();
	void DFS(Node* root);
	void copyRobotLists(vector<Robot*> &L_source , vector<Robot*> &L_dest);
	void print_graphToFileVisual_presentation(Graph *g);
	void  print_graphToOutPutFile(Graph *g);
	void writeDespliteNode(vector<Node*> vec);
	void update_output_string(Graph *g,bool b);
	Node* returnSonToGiveRobotTo(Node* currentNodeOfRobot);
	bool chackIfNeedToKeepRobotForCommunication(CalNodeData &data,Node* son,Node* currentNodeOfRobot);
	Node* DespliteReturnSonToGiveRobotTo(Node* currentNodeOfRobot);
	string ss(int s);
	void writeGraph(Graph *g);
	bool checkConnectivity();
	void recurseConnectivity(Node *node,vector<int> &arr);
	void removeRobots(vector<Robot*> rob_vec,vector<int> &removeFrom);
	virtual ~Cal_Future_Graph();
};

#endif /* CALFUTUREGRAPH_H_ */
