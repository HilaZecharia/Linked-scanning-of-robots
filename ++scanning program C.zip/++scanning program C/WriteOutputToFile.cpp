
#include "WriteOutputToFile.h"
/*connstructor*/
WriteOutputToFile::WriteOutputToFile() { }
/*********************************************
*this function write the output of the 
*scanning to file
*********************************************/
void WriteOutputToFile::WriteToFile(string s,string path){
	   ofstream myfile;
	   myfile.open(path.c_str());
	  if (myfile.is_open())
	  {
	    myfile << s;

	    myfile.close();
	  }
	  else cout << "Unable to open file";
}
/*********************************************
*this function writing all the nodes which
*in desplite level to file
*********************************************/
void WriteOutputToFile::writeNodeDespliteToFile(string s){
	
	   ofstream myfile;
	   myfile.open("Node_desplite.txt");
	  if (myfile.is_open())
	  {
	    myfile << s;

	    myfile.close();
	  }
	  else cout << "Unable to open file";
}
/*********************************************
*this function writing the grapg to file
*********************************************/
void WriteOutputToFile::writeRandomGraph(string str){
	 ofstream myfile;
	   myfile.open("Graph.txt");
	  if (myfile.is_open())
	  {
	    myfile << str;

	    myfile.close();
	  }
	  else cout << "Unable to open file";

}
/*destructor*/
WriteOutputToFile::~WriteOutputToFile() {}

