#include "Graph.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>  
 
using namespace std;
class ReadFromFile
{
private :
	Graph *g;
public:
	ReadFromFile(Graph *g);
	void readInputFile(char* path);
	vector<int> parseSonsString(string son_str);
	vector<int> convertToInt(vector<string> v);
};

