#include "CreateRandomGraph.h"

int count=0;
int global=0;

/*constructor*/
CreateRandomGraph::CreateRandomGraph(int brunch_factor,int deep,Graph *g,int treshHold)
{
	this->brunch_factor=brunch_factor;//the branch-factor of the each node
	this->deep=deep;//the maximum deep of the graph
	this->graph=g;
	//The probability of generating son node
	this->random_numberTreshHold=treshHold; 
}
/*********************************************
*this function create the nodes of the random
*graph
*********************************************/
Node* CreateRandomGraph::createRoot(){
	Node *root=graph->create_New_Node(global);
	global++;
	BuildRandomGraph(root,deep,1);
	return root;
}
/*******************************************
*return a random number between 1 to 10
*******************************************/
int random(int max)
{
    return rand() / (RAND_MAX / max + 1);
}

/*********************************************
*this function create sons to node "n" , in
*randommcly way, it peacks a random number
*between 1 to 10 and if the number is bigger then
*the treshhold it create noe son node
*********************************************/
void CreateRandomGraph::createSonsRandomly(Node *n){
	if(n!=NULL){
		int i;
		for(i=0;i<brunch_factor;i++){
			int r=  random(10);
			if(r >= random_numberTreshHold){
				Node *son=graph->create_New_Node(global);
				global++;
				graph->addEdge(graph->create_New_Node(n->getName()),graph->create_New_Node(son->getName()));
			}
		}

	}

}


/*********************************************
*this function buidlding the graph recurssivly
*********************************************/
void CreateRandomGraph::BuildRandomGraph(Node *node,int MaxDeep,int currentDeep){
	//currentDeep is how many time we try to create sons 
	if(currentDeep>MaxDeep)
		return;//return from the recurssion
	else{
		createSonsRandomly(node);
		vector<Node*>::iterator it;
		vector<Node*> v_s=node->get_vector_sons();

		for (it = v_s.begin();it != v_s.end(); ++it){
			//createSonsRandomly(*it);
		
			BuildRandomGraph(*it, MaxDeep,currentDeep+1);
		}
	
	}
}





