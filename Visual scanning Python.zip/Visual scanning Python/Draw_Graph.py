

import pygraphviz as pgv


# Python program to print DFS traversal for complete graph
from collections import defaultdict



outputSTR=""
################################
#this method splite the neighbors
#string to the neighbors and return
#list of all the neighbors
################################
def getNeighborsList(neighbors_str):
    str=neighbors_str[1:len(neighbors_str)-1]
    if str!='':
        ls = str.split(',')

        return ls
    else:
        return None
################################
#this method get the time from
#the line which was just readed
################################
def getTime(line):
    a=line.split(':')
    return int(a[1])
################################
#this method get the node from
#the string node
#and return the name of it
################################
def getNode(node):
    n=node.split(':')
    return int(n[1])


################################
#this method get the robots which
#is in the node and return a the
#name of it
################################
def getNodeRobots(robots):
    r = robots.split(':')
    return r[1]
################################
#this method get the state of the
#node and return the number of it
################################
def getNodeState(state):
    s = state.split(':')
    return int(s[1])
################################
#this methos delete files
#which is in the path in the input
################################
def deteleFile(path):
    import os, shutil
    folder = path
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
                # elif os.path.isdir(file_path): shutil.rmtree(file_path)
        except Exception as e:
            print(e)



class Graph:

    # Constructor
    def __init__(self):

        # default dictionary to store graph


       self.graph = {}


    # function to add an edges to graph
    def addEdge(self, u, ls_neighbors):
       # self.graph[u].append(v)
       self.graph[u] = ls_neighbors






# Create a graph given in the above diagram

G=pgv.AGraph(directed=True, layout="dot", pad="0.1", rankdir="TB" ,)
G.node_attr["shape"] = "circle"

g = Graph()

file_input=open("input.txt",'r') #open input file
for line in file_input: #read each line from file

    vertex=int(line[1:line.find(']')])
    neighbors_str=line[line.find(']')+1:len(line)-1]
    ls_neighbors=getNeighborsList(neighbors_str) #return list of all the neighbors of the current vertex
    if(ls_neighbors!= None):
        results = map(int, ls_neighbors)#mapping the neighbors to list of int's
    else:
        results=[]
    g.addEdge(vertex, results) #add the edge between the current vertex to its neighbors



file_input.close()
b=[]
file_Node_Desplite=open("desplite.txt",'r')
for line in file_Node_Desplite:
    b = line.split(",")

if not b:
    c = []
else:
    c = [int(e) for e in b]

for key in g.graph:
    G.add_node(key)
    if(key in c): #change deplite node shape to box for recognazing
        G.get_node(key).attr["shape"]="box"

for key in g.graph:
    for neighbor in g.graph[key]:
        G.add_edge(key, neighbor) #add the edge between the node to its neighbor


#*********************
#clean  folders
deteleFile("./Dos")  # delete all the files in the "Dos" folder before writing files to it
deteleFile("./IMG")  # delete all the files in the "IMG" folder before writing


file_out = open("scanning_for_Visual_presentation.txt", 'r')  # open input file
for line in file_out:  # read each line from file
    if ("$$$$$$$$$$$$$$$$$$$$" in line):
        continue


    elif("time:" in line):

        time=getTime(line)

    elif("********************" in line):

        s_path = "Dos/time" + time.__str__() + ".dot"

        G.write(s_path)  # write to simple.dot

        B = pgv.AGraph(s_path)  # create a new graph from file
        B.layout()  # layout with default (neato)
        s_path_img = "IMG/time" +time.__str__() + ".png"

        B.draw(s_path_img)  # draw png

    else:

        line_token=line.split('#')


        node=getNode(line_token[0])
        numOfRobots=getNodeRobots(line_token[1])
        state=getNodeState(line_token[2])

        node = G.get_node(node)
        if(state==2):#not visited
            node.attr["color"] = "black"


            node.attr["label"] = numOfRobots
        elif(state==1):#visited
            node.attr["color"] = "blue"
            node.attr["style"] = "filled"

            node.attr["label"] = numOfRobots
        elif(state==3):#inhabited
            node.attr["color"] = "yellow"
            node.attr["style"] = "filled"

            node.attr["label"] = numOfRobots


file_out.close()
